version="1.1.1"
tags={
	"Gameplay"
	"Religion"
	"Character Interactions"
	"Decisions"
	"Events"
	"Fantasy"
}
name="Divine Ascension - Living God"
supported_version="1.21.*"
picture="thumbnail.png"
