version="1.1.1"
tags={
	"Gameplay"
	"Character Interactions"
	"Decisions"
	"Events"
	"Warfare"
	"Fantasy"
}
name="Legio Invicta - Sons of Mars"
supported_version="1.20.*"
picture="thumbnail.png"
path="mod/legio_invicta"
