version="1.0.2"
tags={
	"Gameplay"
	"Religion"
	"Decisions"
	"Graphics"
}
name="Sacred Architecture - Choose Your Temples"
supported_version="1.20.*"
path="mod/sacred_architecture"
