version="1.0.4"
tags={
	"Gameplay"
	"Character Interactions"
	"Decisions"
	"Events"
	"Game Rules"
}
name="Royal Concubines & Amazon Guard"
supported_version="1.20.*"
picture="thumbnail.png"
path="mod/royal_concubines_amazons"
