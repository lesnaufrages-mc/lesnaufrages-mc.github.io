version="1.1.0"
tags={
	"Gameplay"
	"Religion"
	"Decisions"
	"Events"
	"Game Rules"
}
name="Holy Conquest - Sanctify and Exile Holy Sites"
supported_version="1.20.*"
picture="thumbnail.png"
path="mod/holy_conquest"
