version="1.0.0"
tags={
	"Gameplay"
	"Culture"
	"Decisions"
	"Game Rules"
}
name="Cultural Exchange - Adopt Foreign Styles and Buy Innovations"
supported_version="1.20.*"
picture="thumbnail.png"
path="mod/cultural_exchange"
