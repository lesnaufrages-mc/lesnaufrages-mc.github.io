version="1.1.0"
tags={
	"Gameplay"
	"Religion"
	"Character Interactions"
	"Decisions"
	"Events"
	"Fantasy"
}
name="Divine Ascension - Living God"
supported_version="1.20.*"
picture="thumbnail.png"
