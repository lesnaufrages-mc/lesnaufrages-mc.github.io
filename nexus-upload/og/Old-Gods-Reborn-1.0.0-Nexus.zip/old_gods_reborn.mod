version="1.0.0"
tags={
	"Gameplay"
	"Religion"
	"Decisions"
	"Game Rules"
	"Alternative History"
}
name="Old Gods Reborn - Neo-Pagan Faiths for Later Cultures"
supported_version="1.20.*"
picture="thumbnail.png"
path="mod/old_gods_reborn"
